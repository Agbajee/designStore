@include('public.products.show.custom_options.input', ['attributes' => [
    'type' => 'text',
    'class' => 'datetime-picker',
    'data-time' => true,
]])
