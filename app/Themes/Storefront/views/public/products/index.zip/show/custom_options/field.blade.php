@include('public.products.show.custom_options.input', ['attributes' => [
    'type' => 'text',
]])
